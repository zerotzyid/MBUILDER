void main() { test("placeholder", () {}); }
